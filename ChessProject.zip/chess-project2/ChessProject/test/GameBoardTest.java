/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Game.Game;
import Game.Player;
import Pieces.Bishop;
import Pieces.Horse;
import Pieces.King;
import Pieces.Pawn;
import Pieces.Piece;
import Pieces.Queen;
import Pieces.Rook;
import java.awt.Color;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author bdg7335
 */
public class GameBoardTest {
    
    public static Game setUpClass() {
        Player testPlayer1 = new Player(Color.BLACK, "testp1");
        Player testPlayer2 = new Player(Color.WHITE, "testp1");
        Game game = new Game(testPlayer1, testPlayer2);
        return game;
    }
    
    @Test
    public void testPlayer1IsBlack() {
        Game game = GameBoardTest.setUpClass();
        Color color1 = game.player1.playerColor;
        Color expectedColor = Color.BLACK;
        assertEquals(expectedColor, color1);
    }
    
    @Test
    public void testPlayer2IsWhite() {
        Game game = GameBoardTest.setUpClass();
        Color color2 = game.player2.playerColor;
        Color expectedColor = Color.WHITE;
        assertEquals(expectedColor, color2);
    }
    
    @Test
    public void testMovePieceInBounds() {
        Game game = GameBoardTest.setUpClass();
        
        //Test piece move
        game.gameBoard.movePiece(game.gameBoard.boardArray[6][3], 3, 5);
        assertEquals(true, game.gameBoard.pieceMoved);
    }
    
    @Test
    public void testMovePieceOutOfBounds() {
        Game game = GameBoardTest.setUpClass();
        
        //Test moving pawn 3 squares up
        game.gameBoard.movePiece(game.gameBoard.boardArray[6][3], 3, 3);
        assertEquals(false, game.gameBoard.pieceMoved);
    }
    
    @Test
    public void testTurnsAlternate() {
        Game game = GameBoardTest.setUpClass();
        assertEquals(true, game.gameBoard.blackTurn);
        //Test piece move player1
        game.gameBoard.movePiece(game.gameBoard.boardArray[6][3], 3, 5); // valid player1 move
        assertEquals(false, game.gameBoard.blackTurn);
        //Test piece move player2
        game.gameBoard.movePiece(game.gameBoard.boardArray[1][3], 3, 2); // valid player2 move
        assertEquals(true, game.gameBoard.blackTurn);
    }
    
    @Test
    public void testEmptyCell() {
        Game game = GameBoardTest.setUpClass();
        for(int i = 0; i < 8; i++) {
            assertEquals(false, game.gameBoard.isCellEmpty(i, 6));
        }
        for(int i = 0; i < 8; i++) {
            assertEquals(true, game.gameBoard.isCellEmpty(i, 3));
        }
    }
    
    @Test
    public void testPieceIsCapturing() {
    }
    
    @Test
    public void testInitialPiecesOnBoardArray() {
        //test pawns at right place
        Game game = GameBoardTest.setUpClass();
        
        //INITIALISE BOARD ARRAY
        Piece[][] pieces = game.gameBoard.boardArray;
        // checking if player 1 Pieces are at right place
        for(int i = 0; i < 8; i++) {
            if(!(pieces[6][i] instanceof Pawn)) {
                fail("no pawn where it is supposed to be initially");
            }
        }
        if(!(pieces[7][0] instanceof Rook) || !(pieces[7][7] instanceof Rook)) {
            fail("incorrect piece where rook supposed to be");
        }
        if(!(pieces[7][1] instanceof Bishop) || !(pieces[7][6] instanceof Bishop)) {
            fail("incorrect piece where bishop supposed to be");
        }
        if(!(pieces[7][2] instanceof Horse) || !(pieces[7][5] instanceof Horse)) {
            fail("incorrect piece where rook supposed to be");
        }
        if(!(pieces[7][4] instanceof King)) {
            fail("incorrect piece where rook supposed to be");
        }
        if(!(pieces[7][3] instanceof Queen)) {
            fail("incorrect piece where queen supposed to be");
        }
        
        
        // checking if player 2 Pieces are at right place
        for(int j = 0; j < 8; j++) {
            if(!(pieces[1][j] instanceof Pawn)) {
                fail("no pawn where it is supposed to be initially");
            }
        }
        if(!(pieces[0][0] instanceof Rook) || !(pieces[0][7] instanceof Rook)) {
            fail("incorrect piece where rook supposed to be");
        }
        if(!(pieces[0][1] instanceof Bishop) || !(pieces[0][6] instanceof Bishop)) {
            fail("incorrect piece where bishop supposed to be");
        }
        if(!(pieces[0][2] instanceof Horse) || !(pieces[0][5] instanceof Horse)) {
            fail("incorrect piece where rook supposed to be");
        }
        if(!(pieces[0][4] instanceof King)) {
            fail("incorrect piece where rook supposed to be");
        }
        if(!(pieces[0][3] instanceof Queen)) {
            fail("incorrect piece where queen supposed to be");
        }
    }
}
