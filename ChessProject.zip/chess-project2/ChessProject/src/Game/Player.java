/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Game;

import Exceptions.InvalidUsernameException;
import java.awt.Color;

/**
 *
 * @author bdg7335
 */
public class Player {
    public Color playerColor;
    public boolean isWinner = false;
    public Game currentGame;
    public String playerName;
    public int playerScore;
    private int playerID;
    
    public Player(Color playerColor, String playerName) {
        if(playerColor == Color.BLACK) {
            playerID = 1;
        }
        else {
            playerID = 2;
        }
        doCheck(playerName, " Invalid Username input for player : " + playerID + "\n • at least 1 letter \n • at least 3 characters \n • no spaces or invalid characters");
        this.playerColor = playerColor;
        this.playerName = playerName;
        playerScore = 0;
    }
    
    private static void doCheck(String name, String args) {
        if (!name.matches("\\b[a-zA-Z][a-zA-Z0-9\\-._]{3,}\\b")) {
            throw new InvalidUsernameException(args);
        }
    }
}
